"""Interactive CLI transport for an independent human/Agent-directed acceptance run.

No cases, source expectations, or scene decisions are encoded here. Every command
arrives on stdin after the Agent has inspected the preceding public CLI response.
The local server and CLI share this process's network namespace.
"""
import datetime
import json
import os
from pathlib import Path
import shlex
import socket
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/e3ad139ce787/plc-workspace')
OUT = Path('/workspace/scratch/e3ad139ce787/agent-simulation-acceptance')
URL = 'http://127.0.0.1:8776'
RUN_PREFIX = (sys.argv[1] + '-') if len(sys.argv) > 1 else ''
ENV = os.environ.copy()
ENV.update(SIM_IEC2C='/workspace/scratch/e3ad139ce787/tools/matiec/iec2c',
           SIM_MATIEC_LIB='/workspace/scratch/e3ad139ce787/tools/matiec/lib',
           PLC_OIP_DIR='/workspace/scratch/e3ad139ce787/tools/open-industry-project')

def invoke(name, args, timeout=240):
    name = RUN_PREFIX + name
    argv = [sys.executable, 'web/scripts/plc-agent.py', '--url', URL, *args]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / (name + '.command.json')).write_text(json.dumps({'cwd':str(ROOT), 'argv':argv, 'started_at':started}, ensure_ascii=False, indent=2))
    with (OUT / 'commands.sh').open('a') as log:
        log.write(shlex.join(argv) + '\n')
    try:
        result = subprocess.run(argv, cwd=ROOT, env=ENV, text=True, capture_output=True, timeout=timeout)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or b''
        stderr = exc.stderr or b''
        stdout = stdout.decode() if isinstance(stdout, bytes) else stdout
        stderr = stderr.decode() if isinstance(stderr, bytes) else stderr
        code = 124
    (OUT / (name + '.stdout.json')).write_text(stdout)
    (OUT / (name + '.stderr.txt')).write_text(stderr)
    record = {'name': name, 'argv': argv, 'exit_code':code, 'started_at':started,
              'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'stdout':stdout, 'stderr':stderr}
    with (OUT / 'operations.jsonl').open('a') as log:
        log.write(json.dumps(record, ensure_ascii=False)+'\n')
    print(json.dumps(record, ensure_ascii=False), flush=True)

invoke('00-prestart-doctor', ['doctor'])
server_args = [sys.executable, 'web/scripts/local-server.py', '--port', '8776', '--runtime-root', str(OUT/(RUN_PREFIX+'server-runtime'))]
(OUT/(RUN_PREFIX+'server.command.json')).write_text(json.dumps({'cwd':str(ROOT), 'argv':server_args, 'environment':{k:ENV[k] for k in ('SIM_IEC2C','SIM_MATIEC_LIB','PLC_OIP_DIR')}}, indent=2))
server_log = (OUT/(RUN_PREFIX+'server.log')).open('w')
server = subprocess.Popen(server_args, cwd=ROOT, env=ENV, stdout=server_log, stderr=subprocess.STDOUT)
try:
    for _ in range(100):
        if server.poll() is not None:
            raise RuntimeError('Local server exited; inspect server.log')
        try:
            with socket.create_connection(('127.0.0.1',8776),timeout=.1):
                break
        except OSError:
            time.sleep(.05)
    invoke('01-doctor',['doctor'])
    print(json.dumps({'driver':'ready', 'url':URL, 'server_pid':server.pid}), flush=True)
    for line in sys.stdin:
        try:
            command=json.loads(line)
            if command.get('shutdown'):
                break
            invoke(command['name'],command['args'],command.get('timeout',240))
        except Exception as exc:
            print(json.dumps({'driver_error':str(exc)}), flush=True)
finally:
    server.terminate()
    try:
        server.wait(timeout=10)
    except subprocess.TimeoutExpired:
        server.kill()
        server.wait()
    server_log.close()
    print(json.dumps({'driver':'closed','server_exit_code':server.returncode}),flush=True)
